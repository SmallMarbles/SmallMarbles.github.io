dpkg-deb -bZgzip projects/NsB debs
dpkg-deb -bZgzip projects/Nicon debs
